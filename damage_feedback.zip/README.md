<h1 align="center">Damage Feedback</h1>


A damage feedback display that shows the damage done to a player when using firearms. Displays the damage dealt to a player in a configurable marker on the screen.


## Configuration
 - Indicator style.
 - Indicator life time.

## Installation
1. Place damage_feedback in your resources directory.
2. Add ensure damage_feedback to your server.cfg.

## Screenshots
[Video](https://streamable.com/p9p5cw)

## Credits
A lot of code copy pasted from [here](https://github.com/NIYCCO/niycco_hitmarker).
